//
//  HerculesAppApp.swift
//  HerculesApp
//
//  Created by Phoebe Sim on 7/11/25.
//

import SwiftUI

@main
struct HerculesAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            
        }
    }
}


